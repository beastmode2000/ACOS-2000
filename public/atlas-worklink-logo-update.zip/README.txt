Atlas Work Links Logo Update

Files included:
- app/page.tsx
- public/worklink-landscape-help-admin.png
- public/worklink-control4.png
- public/worklink-tcc-honeywell.png
- public/worklink-metaviewer.png

Install:
1. In GitHub, replace app/page.tsx with app/page.tsx from this package.
2. Upload all four PNG files into the repo public folder.
3. Commit the changes and let Vercel redeploy.

Changed only Work Links logo references/rendering. Auth, middleware, API, Neon, Landscape Help route, and PWA files were not changed.
