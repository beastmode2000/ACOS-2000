const ATLAS_SW_VERSION = "atlas-2000-pwa-v1";

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", () => {
  // Network-first. Atlas data remains live; this service worker enables app-style install support.
});
