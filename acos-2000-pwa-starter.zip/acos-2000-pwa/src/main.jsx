import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Map, Wrench, ClipboardList, Droplets, Paintbrush, Camera, Users, Folder, Settings, Search, QrCode, Home} from 'lucide-react';
import './style.css';

const sections = [
  'Main House','West Property','Old Garage','New Garage','Back Lawn','East Lawn','Sport Court','Vegetable Garden','Dock','Lakefront','East Gate','Driveway','Second Trampoline','Yew Trees','Boiler Room','Generator Area','Storage'
];

const modules = [
  {title:'Property Map', icon:Map, text:'Clickable estate map with numbered sections.'},
  {title:'Assets', icon:Wrench, text:'Equipment, model numbers, manuals, service history.'},
  {title:'Work Orders', icon:ClipboardList, text:'Open items, priorities, assignments, and completion notes.'},
  {title:'Irrigation', icon:Droplets, text:'Zones, valves, controllers, schedules, repairs.'},
  {title:'Paint Database', icon:Paintbrush, text:'Exterior/interior colors, coats, finish, project photos.'},
  {title:'Photos', icon:Camera, text:'Progress photos by area, date, vendor, and project.'},
  {title:'Vendors', icon:Users, text:'Contacts, scope of work, notes, and service history.'},
  {title:'Documents', icon:Folder, text:'Manuals, proposals, receipts, SOPs, and records.'},
  {title:'QR Codes', icon:QrCode, text:'Scan equipment labels to open asset records instantly.'},
  {title:'Settings', icon:Settings, text:'Users, permissions, backups, and app configuration.'}
];

function App(){
  const [selected,setSelected]=useState('Property Map');
  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="logo"><Home size={24}/></div><div><h1>ACOS</h1><p>Asset & Care Operations System</p></div></div>
      <div className="search"><Search size={18}/><input placeholder="Search assets, vendors, zones..."/></div>
      <nav>{modules.map(m=>{const I=m.icon; return <button key={m.title} onClick={()=>setSelected(m.title)} className={selected===m.title?'active':''}><I size={19}/>{m.title}</button>})}</nav>
    </aside>
    <main>
      <header><p>2000 Operations Platform</p><h2>{selected}</h2></header>
      {selected==='Property Map'? <MapView/>:<ModuleView selected={selected}/>}      
    </main>
  </div>
}

function ModuleView({selected}){
  const mod=modules.find(m=>m.title===selected); const I=mod.icon;
  return <section className="panel"><div className="moduleHero"><I size={42}/><div><h3>{mod.title}</h3><p>{mod.text}</p></div></div>
    <div className="grid cards"><div><b>Next build item</b><p>Add editable records and autosaved details.</p></div><div><b>Status</b><p>Phase 1 shell is ready for data entry.</p></div><div><b>Recommended</b><p>Connect this module to section pages and asset QR codes.</p></div></div>
  </section>
}

function MapView(){return <section className="panel"><div className="mapWrap"><div className="estateMap">
  {sections.map((s,i)=><button key={s} className={`pin p${i+1}`} title={s}>{i+1}</button>)}
  <div className="label house">Main House</div><div className="label garage">Garages</div><div className="label lake">Lakefront / Dock</div>
</div></div>
  <h3>Clickable Property Sections</h3><div className="sectionGrid">{sections.map((s,i)=><article key={s}><span>{i+1}</span><div><b>{s}</b><p>Photos • Assets • Vendors • Notes • Maintenance</p></div></article>)}</div></section>}

createRoot(document.getElementById('root')).render(<App/>);
