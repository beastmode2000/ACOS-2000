import './globals.css';
export const metadata={title:'ACOS-2000',description:'Asset & Care Operations System'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
