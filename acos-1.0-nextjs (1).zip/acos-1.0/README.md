# ACOS-2000

Asset & Care Operations System for 2000.

## Deploy
This is a Next.js app designed for Vercel.

## Current version
Phase 1 dashboard starter with property sections, asset placeholders, vendor placeholders, and PWA-ready structure.
